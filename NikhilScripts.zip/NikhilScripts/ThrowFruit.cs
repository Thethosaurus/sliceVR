﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThrowFruit : MonoBehaviour {

	public Rigidbody rb;
	double timer = 0.0;
	public int force = 500;

	void FixedUpdate() {
		rb = GetComponent<Rigidbody>();
		timer += Time.deltaTime;
		if (timer > 10){
			force += 50;
			timer = 0.0;
		}
		rb.AddForce(force * Time.deltaTime,500 * Time.deltaTime,0);
	}
}
